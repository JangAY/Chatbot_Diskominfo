import json
import re
import sys
import os # <-- Tambahkan modul os
import chromadb
from sentence_transformers import SentenceTransformer

# --- BAGIAN YANG DIPERBAIKI ---
# Tentukan path absolut ke direktori tempat skrip ini berada
# Ini adalah kunci agar skrip bisa menemukan file-filenya sendiri
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "chatbot_db")
JSON_PATH = os.path.join(SCRIPT_DIR, "knowledge_base.json")

# Inisialisasi model dan ChromaDB Client menggunakan path absolut
model = SentenceTransformer('all-MiniLM-L6-v2')
client = chromadb.PersistentClient(path=DB_PATH) 
# --- AKHIR BAGIAN YANG DIPERBAIKI ---

# Coba ambil collection, tangani jika belum dibuat
try:
    site_guide_collection = client.get_collection(name="panduan_situs")
    dataset_collection = client.get_collection(name="kumpulan_dataset")
except ValueError as e:
    # Kirim pesan error yang jelas jika database belum dibuat
    print(f"Error: Database ChromaDB belum dibuat. Jalankan 'build_knowledge_base.py' terlebih dahulu. Detail: {e}")
    sys.exit(1) # Keluar dari skrip dengan status error

def classify_intent(query: str) -> str:
    """
    Model sederhana untuk mengklasifikasikan maksud pengguna.
    """
    dataset_keywords = [
        'data', 'dataset', 'jumlah', 'angka', 'statistik', 
        'laporan', 'daftar', 'tampilkan', 'berikan', 'cari'
    ]
    query_lower = query.lower()
    if any(keyword in query_lower for keyword in dataset_keywords):
        return 'dataset_search'
    return 'general_question'

def handle_general_question(query: str) -> str:
    """
    Menangani pertanyaan umum menggunakan RAG.
    """
    query_embedding = model.encode([query]).tolist()
    
    results = site_guide_collection.query(
        query_embeddings=query_embedding,
        n_results=1
    )
    
    if not results['documents'][0]:
        return "Maaf, saya tidak dapat menemukan informasi mengenai hal tersebut."
        
    context = results['documents'][0][0]
    
    # Di aplikasi nyata, Anda bisa memanggil LLM di sini untuk merangkum `context`
    # Untuk sekarang, mengembalikan konteks langsung sudah cukup baik.
    return context

def handle_dataset_search(query: str) -> str:
    """
    Menangani permintaan pencarian dataset.
    """
    year_match = re.search(r'\b(20\d{2})\b', query)
    year = year_match.group(1) if year_match else None
    topic_query = re.sub(r'\b(20\d{2})\b', '', query).strip()

    query_embedding = model.encode([topic_query]).tolist()
    
    results = dataset_collection.query(
        query_embeddings=query_embedding,
        n_results=15 # Ambil lebih banyak untuk filtering
    )

    found_datasets = []
    if results['ids'][0]:
        for i, doc_id in enumerate(results['ids'][0]):
            metadata = results['metadatas'][0][i]
            title_year_match = re.search(r'\b(20\d{2})\b', metadata['title'])
            dataset_year = title_year_match.group(1) if title_year_match else None
            
            if year and year != dataset_year:
                continue
            
            found_datasets.append({
                "nama_dataset": metadata['title'],
                "link": metadata['url']
            })
            
            if len(found_datasets) >= 5:
                break

    if not found_datasets:
        return "Maaf, saya tidak dapat menemukan dataset yang sesuai dengan permintaan Anda. Coba gunakan kata kunci yang lebih spesifik."
    
    table_header = "| Nama Dataset | Tautan |\n| :--- | :--- |\n"
    table_rows = ""
    for ds in found_datasets:
        table_rows += f"| {ds['nama_dataset']} | [Lihat Dataset]({ds['link']}) |\n"
    
    markdown_table = table_header + table_rows
    
    response = (
        "Tentu, saya menemukan beberapa dataset yang relevan dengan pencarian Anda:\n\n"
        f"{markdown_table}\n"
        "Anda dapat mengklik tautan di atas untuk melihat detail lebih lanjut."
    )
    
    return response

def main_chatbot_handler(user_query: str):
    """
    Fungsi utama yang akan dipanggil oleh endpoint API.
    """
    intent = classify_intent(user_query)
    
    if intent == 'general_question':
        response = handle_general_question(user_query)
    elif intent == 'dataset_search':
        response = handle_dataset_search(user_query)
    else:
        response = "Maaf, saya tidak mengerti permintaan Anda."
        
    return response

if __name__ == '__main__':
    if len(sys.argv) > 1:
        user_query = sys.argv[1]
        response = main_chatbot_handler(user_query)
        print(response)
    else:
        # Mengembalikan error ke stderr agar bisa ditangkap Laravel jika tidak ada argumen
        sys.stderr.write("Error: No query provided.")
        sys.exit(1)