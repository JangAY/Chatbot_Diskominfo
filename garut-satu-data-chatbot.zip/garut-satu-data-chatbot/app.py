import os
import re
import json
import sys
import chromadb
from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify
from flask_cors import CORS

# --- 1. INISIALISASI (Hanya berjalan sekali saat server dimulai) ---
print("Flask: Memulai aplikasi dan memuat model...")

# Tentukan path absolut untuk keandalan maksimal
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "chatbot_db")

# Inisialisasi aplikasi Flask dan aktifkan CORS
app = Flask(__name__)
# Izinkan permintaan dari frontend Next.js Anda
CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})

# Muat model embedding
model = SentenceTransformer('all-MiniLM-L6-v2')

# Hubungkan ke Vector Database
try:
    client = chromadb.PersistentClient(path=DB_PATH)
    site_guide_collection = client.get_collection(name="panduan_situs")
    dataset_collection = client.get_collection(name="kumpulan_dataset")
    print("Flask: Model dan database berhasil dimuat.")
except Exception as e:
    print(f"!!! KESALAHAN FATAL: Tidak dapat memuat database ChromaDB.")
    print(f"!!! PASTIKAN Anda telah menjalankan 'python build_knowledge_base.py' terlebih dahulu.")
    print(f"!!! Detail Error: {e}")
    # Set collection ke None agar aplikasi tidak crash, tapi akan mengembalikan error saat API dipanggil
    site_guide_collection = None
    dataset_collection = None

# --- 2. FUNGSI LOGIKA CHATBOT (Sama seperti sebelumnya) ---

def classify_intent(query: str) -> str:
    dataset_keywords = ['data', 'dataset', 'jumlah', 'angka', 'statistik', 'laporan', 'daftar', 'tampilkan', 'berikan', 'cari']
    return 'dataset_search' if any(keyword in query.lower() for keyword in dataset_keywords) else 'general_question'

def handle_general_question(query: str) -> str:
    if not site_guide_collection:
        return "Error: Database panduan situs tidak dapat diakses. Pastikan server backend berjalan dengan benar."
    query_embedding = model.encode([query]).tolist()
    results = site_guide_collection.query(query_embeddings=query_embedding, n_results=1)
    if not results['documents'][0]:
        return "Maaf, saya tidak dapat menemukan informasi mengenai hal tersebut."
    return results['documents'][0][0]

def handle_dataset_search(query: str) -> str:
    if not dataset_collection:
        return "Error: Database dataset tidak dapat diakses. Pastikan server backend berjalan dengan benar."
        
    year_match = re.search(r'\b(20\d{2})\b', query)
    year = year_match.group(1) if year_match else None
    topic_query = re.sub(r'\b(20\d{2})\b', '', query).strip()

    query_embedding = model.encode([topic_query]).tolist()
    results = dataset_collection.query(query_embeddings=query_embedding, n_results=15)

    found_datasets = []
    if results['ids'][0]:
        for i, doc_id in enumerate(results['ids'][0]):
            metadata = results['metadatas'][0][i]
            title_year_match = re.search(r'\b(20\d{2})\b', metadata['title'])
            dataset_year = title_year_match.group(1) if title_year_match else None
            
            if year and year != dataset_year:
                continue
            
            found_datasets.append({"nama_dataset": metadata['title'], "link": metadata['url']})
            if len(found_datasets) >= 5:
                break

    if not found_datasets:
        return "Maaf, saya tidak dapat menemukan dataset yang sesuai dengan permintaan Anda. Coba gunakan kata kunci yang lebih spesifik."

    table_header = "| Nama Dataset | Tautan |\n| :--- | :--- |\n"
    table_rows = "".join([f"| {ds['nama_dataset']} | [Lihat Dataset]({ds['link']}) |\n" for ds in found_datasets])
    markdown_table = table_header + table_rows
    
    return (
        "Tentu, saya menemukan beberapa dataset yang relevan dengan pencarian Anda:\n\n"
        f"{markdown_table}\n"
        "Anda dapat mengklik tautan di atas untuk melihat detail lebih lanjut."
    )

# --- 3. ENDPOINT API FLASK ---

@app.route("/api/chat", methods=["POST"])
def handle_chat():
    # Ambil data JSON dari permintaan
    data = request.get_json()
    if not data or 'query' not in data:
        return jsonify({"error": "Permintaan tidak valid, 'query' dibutuhkan."}), 400

    user_query = data['query']
    
    # Proses query menggunakan logika chatbot
    intent = classify_intent(user_query)
    
    if intent == 'general_question':
        response_text = handle_general_question(user_query)
    elif intent == 'dataset_search':
        response_text = handle_dataset_search(user_query)
    else:
        response_text = "Maaf, saya tidak mengerti permintaan Anda."

    # Kembalikan respons dalam format JSON
    return jsonify({"reply": response_text})

# --- 4. JALANKAN SERVER FLASK ---

if __name__ == "__main__":
    # Jalankan server di port 5000 dengan mode debug
    app.run(host='0.0.0.0', port=5000, debug=True)